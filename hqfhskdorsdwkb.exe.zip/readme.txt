hqfhskdorsdwkb.exe
A date-timed Trojan Malware made in VB.net and C++ over the course of a few hours
Requires .NET Framework 2.0 or 3.5
Works on Windows XP (except for Home and Starter Editions) and (possibly) later Windows versions
Credits to JhoPro/ArTicZera for the AlphaBlend, Date Checking code (I fixed it up a bit) and the original MBR code I based off the MBR of
Creation date: December 27 2023
I know I said that I stopped making GDI malwares after finishing APM 08279+5255.exe, but I will still ocasionally make other types of malware or collab malwares as well as malwares for eventual malware competitions